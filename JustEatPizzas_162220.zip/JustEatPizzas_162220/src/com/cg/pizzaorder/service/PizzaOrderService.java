package com.cg.pizzaorder.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.dao.IPizzaOrderDAO;
import com.cg.pizzaorder.dao.PizzaOrderDAO;
import com.cg.pizzaorder.exception.PizzaException;
import com.cg.pizzaorder.service.IPizzaOrderService;

public class PizzaOrderService implements IPizzaOrderService
{
	static IPizzaOrderDAO ipd= new PizzaOrderDAO(); ;
	//The method to add the details in the map
	@Override
	public int placeOrder(Customer customer, PizzaOrder pizza)
			throws PizzaException 
	{
		
		return ipd.placeOrder(customer,pizza);
		
		
	}
	@Override
	public PizzaOrder displayOrder(int orderid) throws PizzaException {
		// TODO Auto-generated method stub
		return ipd.displayOrder(orderid);
	}
	@Override
	public double Calculateprice(PizzaOrder pizza) {
		// TODO Auto-generated method stub
		return ipd.Calculateprice(pizza);
	}
	
	public boolean validateCustomer(Customer PizzaOrderDao) throws PizzaException 
	{
		List<String> validationErrors = new ArrayList<String>();

		
		//Validating contact Number
				if(!(isValidContactNo(PizzaOrderDao.getPhone()))){
					validationErrors.add("\n Contact Number Should only be 10 digit \n");
				}
				
				
		//Validating customer name
		if(!(isValidCName(PizzaOrderDao.getCustName()))) {
			validationErrors.add("\n   CustomerName Should Be In Alphabets and minimum 3 characters long ! \n");
		}
		
		//Validating favor name
				if(!(isValidAddress(PizzaOrderDao.getAddress()))) {
					validationErrors.add("\n   Address Should Be In Alphabets and minimum 3 characters long ! \n");
				}
				if(!validationErrors.isEmpty())
					throw new PizzaException(validationErrors +"");
				return false;
}
	private boolean isValidAddress(String getaddress) {
		// TODO Auto-generated method stub
		Pattern namePattern=Pattern.compile("^[A-Za-z]{3,}$");
		Matcher nameMatcher=namePattern.matcher(getaddress);
		return nameMatcher.matches();
	}
	private boolean isValidCName(String getcustName) {
		// TODO Auto-generated method stub
		Pattern namePattern=Pattern.compile("^[A-Za-z]{3,}$");
		Matcher nameMatcher=namePattern.matcher(getcustName);
		return nameMatcher.matches();
		
	}
	private boolean isValidContactNo(String phone) {
		// TODO Auto-generated method stub
		Pattern contactPattern=Pattern.compile("^[1-9]{1}[0-9]{9}$");
		Matcher contactMatcher=contactPattern.matcher(phone);
		return contactMatcher.matches();
		
	}
}
	
	//The method to get all the details from the map
	