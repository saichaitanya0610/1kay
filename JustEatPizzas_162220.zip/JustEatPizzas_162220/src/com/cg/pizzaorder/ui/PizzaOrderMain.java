package com.cg.pizzaorder.ui;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;
import java.util.Scanner;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.bean.VegToppings;
import com.cg.pizzaorder.exception.PizzaException;
import com.cg.pizzaorder.service.IPizzaOrderService;
import com.cg.pizzaorder.service.PizzaOrderService;

public class PizzaOrderMain 
{
	static Scanner sc=null;
	static Random rand=null;
	static Customer customer =null;
	static PizzaOrder pizzaorder=null;
	static double totalPrize;
	static IPizzaOrderService ips= new PizzaOrderService(); 
	public static void main(String[] args) throws PizzaException
	{
		sc=new Scanner(System.in);
		int choice;
		while(true)
		{
		System.out.println("1.Place Order");
		System.out.println("2.Display Order");
		System.out.println("3.Exit");
		System.out.println("Enter your Choice");
		choice=sc.nextInt();
		switch(choice){
		case 1: System.out.println("\n Enter Name: ");
		        String name=sc.next();
		        System.out.println("\n Address: ");
		        String address= sc.next();
		        System.out.println("\n Enter phonenumber: ");
		        String number=sc.next();
		        Customer customer= new Customer();
		        customer.setAddress(address);
		        customer.setCustName(name);
		        customer.setPhone(number);
		        System.out.println("\n Type of pizza topping preferred: \n Capsicum \n Mushroom \n Jalapeno \n Paneer");
		        String topping=sc.next();
		        VegToppings vt=VegToppings.valueOf(topping);
		        PizzaOrder pizza = new PizzaOrder();
		        pizza.setToppings(vt);
		        
		        pizza.setOrderdate(new Date());
		        double price = ips.Calculateprice(pizza);
		        pizza.setTotalPrice(price);
		        System.out.println("\n Price: "+ price);
		        int id= ips.placeOrder(customer, pizza);
		        System.out.println("\n Your Pizza Order is placed along with OrderID :"+id);
		        break;
		case 2: System.out.println("\n Enter OrerId: ");
		        int oid= sc.nextInt();
		        PizzaOrder pizza1= ips.displayOrder(oid);
		        System.out.println("\n OrderId: "+ pizza1.getOrderid());
		        System.out.println("\n TotalPrice: "+ pizza1.getTotalPrice());
		        System.out.println("\n OrderDate: "+ pizza1.getOrderdate());
		        break;
		case 3: System.out.println("\n Exit"); break;
		        
		        
		        
		}
		}
	}
}
	