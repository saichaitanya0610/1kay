package com.capgemini.bank.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.exception.DemandDraftException;
import com.capgemini.bank.util.DBConnection;



public class DemandDraftDAO implements IDemandDraftDAO 
{
	
	Logger logger=Logger.getRootLogger();
	public DemandDraftDAO()
	{
	PropertyConfigurator.configure("resources//log4j.properties");
	
	}
	

	//------------------------ 1. Demand Draft --------------------------
	/*******************************************************************************************************
	 - Function Name	:	addDraftDetails(DemandDraft demanddraftbean)
	 - Input Parameters	:	DemandDraft deamnddraftbean
	 - Return Type		:	String
	 - Throws			:  	DemandDraftException
	 - Author			:	CAPGEMINI
	 - Creation Date	:	18/11/2016
	 - Description		:	Adding Demand Draft Details
	 ********************************************************************************************************/
// Adding the Demand Draft Details
	@SuppressWarnings("resource")
	public String addDraftDetails(DemandDraft demanddraftbean) throws DemandDraftException 
	{
		Connection connection = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		
		String transaction_id=null;
		
		int queryResult=0;
		try
		{		
			preparedStatement=connection.prepareStatement(QueryMapper.INSERT_QUERY);
			preparedStatement.setString(1,demanddraftbean.getCustomer_name());			
			preparedStatement.setString(2,demanddraftbean.getIn_favor_of());
			preparedStatement.setString(3,demanddraftbean.getPhone_number());
			preparedStatement.setInt(4,demanddraftbean.getDd_amount());
			preparedStatement.setInt(5,demanddraftbean.getDd_commission());
			preparedStatement.setString(6,demanddraftbean.getDd_description());
			
			queryResult=preparedStatement.executeUpdate();
		
			preparedStatement = connection.prepareStatement(QueryMapper.TRANSID_QUERY_SEQUENCE);
			resultSet=preparedStatement.executeQuery();

			if(resultSet.next())
			{
				transaction_id=resultSet.getString(1);
						
			}
	
			if(queryResult==0)
			{
				logger.error("Inserting Demand Draft details failed ");
				throw new DemandDraftException("Inserting Demand Draft details failed ");

			}
			else
			{
				logger.info("Demand Draft details added successfully:");
				return transaction_id;
			}

		}
		catch(SQLException sqlException)
		{
			sqlException.printStackTrace();
			logger.error(sqlException.getMessage());
			throw new DemandDraftException("Tehnical problem occured refer log");
		}

		finally
		{
			try 
			{
				//resultSet.close();
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				sqlException.printStackTrace();
				logger.error(sqlException.getMessage());
				throw new DemandDraftException("Error in closing db connection");

			}
		}
		
		
	}
// Retrieving the details of Demand Draft using Transaction_Id
	@Override
	public DemandDraft viewDraftDetails(String transaction_id) throws DemandDraftException {
		
			
			Connection connection=DBConnection.getInstance().getConnection();
			
			
			PreparedStatement preparedStatement=null;
			ResultSet resultset = null;
			DemandDraft demanddraftbean=null;
			
			try
			{
				preparedStatement=connection.prepareStatement(QueryMapper.VIEW_DRAFT_DETAILS_QUERY);
				preparedStatement.setString(1,transaction_id);
				resultset=preparedStatement.executeQuery();
				
				if(resultset.next())
				{
					demanddraftbean = new DemandDraft();
					demanddraftbean.setCustomer_name(resultset.getString(1));
					demanddraftbean.setIn_favor_of(resultset.getString(2));
					demanddraftbean.setPhone_number(resultset.getString(3));
					demanddraftbean.setDate_of_transaction(resultset.getDate(4));
					demanddraftbean.setDd_amount(resultset.getInt(5));
					demanddraftbean.setDd_commission(resultset.getInt(6));
					demanddraftbean.setDd_description(resultset.getString(7));
					
				}
				
				if( demanddraftbean != null)
				{
					logger.info("Record Found Successfully");
					return demanddraftbean;
				}
				else
				{
					logger.info("Record Not Found Successfully");
					return null;
				}
				
			}
			catch(Exception e)
			{
				logger.error(e.getMessage());
				throw new DemandDraftException(e.getMessage());
			}
			finally
			{
				try 
				{
					resultset.close();
					preparedStatement.close();
					connection.close();
				} 
				catch (SQLException e) 
				{
					logger.error(e.getMessage());
					throw new DemandDraftException("Error in closing db connection");

				}
			}
			
		}
}